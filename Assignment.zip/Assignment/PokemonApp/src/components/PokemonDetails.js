import React, { useEffect, useState } from "react";
import axios from "axios";

//component for pokemon details
const PokemonDetails = ({ pokemonName }) => {
    const [pokemonDetails, setPokemonDetails] = useState(null);

    useEffect(() => {
        //using axios to retrieve the pokemon via its unique url then render
        axios.get('https://pokeapi.co/api/v2/pokemon/' + pokemonName).then(response => {
            setPokemonDetails(response.data);
        }).catch(error => { console.error(error) });
    }, [pokemonName]);

    if (!pokemonDetails) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h1 className="text-info">Pokemon Details</h1>
            <img
                src={pokemonDetails.sprites.front_default}
            />
            <h2 className="text-muted">{pokemonDetails.name}</h2>
            <span>URL : {pokemonDetails.species.url}</span>
        </div>
    );
};
export default PokemonDetails;
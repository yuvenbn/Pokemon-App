import React, { useEffect, useState } from 'react';
import axios from 'axios';
import PokemonDetails from './PokemonDetails';

const PokemonList = () => {
    //state variables
    const [pokemonList, setPokemonList] = useState([]); 
    const [searchTerm, setSearchTerm] = useState('');
    const [nextPageURL, setNextPageURL] = useState(null);
    const [prevPageURL, setPrevPageURL] = useState(null);
    const [selectedPokemonName, setSelectedPokemonName] = useState('bulbasaur');

    
    useEffect(() => {
        //retrieving pokemon data from the Pokeman API via the URL
        fetchData('https://pokeapi.co/api/v2/pokemon')
    }, []);

    const fetchData = (url) => {
        //using axios library to otain the data
        axios.get(url).then(response => {
            setPokemonList(response.data.results);
            setNextPageURL(response.data.next);
            setPrevPageURL(response.data.previous);
        }).catch(error => {
            console.error(error);
        });
    };

    //Buttons for the previous and next page
    const goToNextPage = () => {
        if (nextPageURL) {
            fetchData(nextPageURL);
        }
    };
    const goToPrevPage = () => {
        if (prevPageURL) {
            fetchData(prevPageURL);
        }
    };

    //Searching: THe pokemon list is obtainedd and filtered based in the input searchTerm
    const handleSearch = () => {
        axios.get('https://pokeapi.co/api/v2/pokemon?offset=1&limit=1281').then(response => {
            setPokemonList(response.data.results.filter(pokemon => pokemon.name.includes(searchTerm.toLowerCase())));
        }).catch(error => {
            console.error(error);
        });
    };

    return (
        <div className='container row'>
            <div className='col'>
                <h1>Pokemon List</h1>
                <input
                    type="text"
                    value={searchTerm}
                    onChange={event => setSearchTerm(event.target.value)}
                    placeholder='Search Pokemon'
                />
                <button onClick={handleSearch} className='btn btn-success'>Search</button>
                <ul>
                    {pokemonList.map(pokemon => (
                        <li key={pokemon.name} className='mt-1'>
                            <div className='row'>
                                <div className='col-4'>
                                    {pokemon.name}
                                </div>
                                <div className='col'>
                                    <button onClick={event => setSelectedPokemonName(pokemon.name)}
                                        className=' btn btn-outline-dark'>
                                        View</button>
                                </div>
                            </div>
                        </li>
                    ))}
                </ul>
                {/* incase there is no match found for the searchTerm */}
                {pokemonList.length === 0 ? (
                    <p>No results!</p>
                ) : (
                    <p></p>
                )}

                <div>
                    <button
                        onClick={goToPrevPage}
                        disabled={!prevPageURL}
                        className='btn btn-secondary mr-5'>
                        Prev
                    </button>
                    <button
                        onClick={goToNextPage}
                        disabled={!nextPageURL}
                        className='btn btn-primary'>
                        next
                    </button>
                </div>
            </div>

            {/* when a user selects a pokemon by clicking View button,
            full details about the pokemon and rendered using PokemonDetails component */}
            <div className='col bg-light'>
                <PokemonDetails pokemonName={selectedPokemonName} />
            </div>

        </div>
    );
};
export default PokemonList;

